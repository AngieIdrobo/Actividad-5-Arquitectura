
package controlador;

import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;
import modelo.Usuario;
import servicio.UsuarioServicio;

public class UsuarioControlador {
    
    private UsuarioServicio usuarioServicio = new UsuarioServicio();
    private Scanner scanner = new Scanner (System.in);
    
    public void mostrarOpciones(){
    
        while(true){
            System.out.println("Digite el número de la opción requerida");
            System.out.println("1. Registrar usuario");
            System.out.println("2. Guardar usuario");
            System.out.println("3. Buscar usuario con el número de identificación");
            System.out.println("4. Eliminar usuario");
            System.out.println("5. Salir del sistema");
            
            int opcion = scanner.nextInt();
            scanner.nextLine(); //Permite limpiar el bufer
            
            switch(opcion){
                case 1:
                    System.out.println("Registrar el número de cédula: ");
                    Long identificacion = scanner.nextLong();
                    System.out.println("Registrar el nombre:  ");
                    String nombre = scanner.nextLine();
                    System.out.println("Registrar el correo electrónico:  ");
                    String correoElectronico = scanner.nextLine();
                    usuarioServicio.guardarUsuarios(new Usuario (identificacion, nombre, correoElectronico));
                    System.out.println("El usuario registrado es: "+ identificacion + " " + nombre + " " + correoElectronico);
                    break;
                    
                case 2:
                    List<Usuario> usuarios = usuarioServicio.registrarUsuarios();
                    usuarios.forEach(usuario -> System.out.println(usuario.getIdentificacion()+ " _ "+ usuario.getNombre()));
                    break;
                    
                case 3:
                    System.out.println("Digite la identificación del usuario: ");
                    Long idMostrador = scanner.nextLong();
                    Usuario usuario = usuarioServicio.buscarUsuarios(idMostrador);
                    
                    if(usuario != null){
                        System.out.println(usuario.getIdentificacion()+ " - " + usuario.getNombre());
                        
                    }   else{
                            System.out.println("El usuario no se encuentra en la base de datos");                             
                              
                            }
                    break;
                    
                case 4:
                    System.out.println("Digite la identificación del usuario a eliminar:  ");
                    Long idEliminar = scanner.nextLong();
                    usuarioServicio.eliminarUsuario(idEliminar);
                    System.out.println("El usuario: " + idEliminar + " ha sido elimminado");
                    
                    break;
                    
                case 5:
                    System.exit(0);
                    
                    break;
                
                default:
                    System.out.println("Esta opción no es válida");
            }
        }
    }
}
