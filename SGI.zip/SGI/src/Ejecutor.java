
import controlador.UsuarioControlador;


public class Ejecutor {

public static void main(String[] args){

UsuarioControlador controlador =  new UsuarioControlador();
controlador.mostrarOpciones();
}    
}
