
package repositorio;

// se importan las librerías
import java.util.ArrayList;
import java.util.List;
import modelo.Usuario;

public class UsuarioRepositorio {
    private List<Usuario> usuarios = new ArrayList<>();
    private Long idMostrador = 1L;

//se crean los métodos para registrar, guardar, buscar y eliminar usuarios    
    public List<Usuario> registrarUsuarios(){
    return usuarios;
    }
    public void guardarUsuarios(Usuario usuario){
        usuario.setIdentificacion(idMostrador++);
        System.out.println("Usuario guardado con identificación: " + usuario.getIdentificacion());
        usuarios.add(usuario);
    }
    public Usuario buscarUsuarios(Long identificacion){
    return usuarios.stream()
            .filter(usuario -> usuario.getIdentificacion().equals(identificacion))
            .findFirst()
            .orElse(null);
    }
    public void eliminarUsuario(Long identificacion){
        usuarios.removeIf(usuario -> usuario.getIdentificacion().equals(identificacion));
    }
}
