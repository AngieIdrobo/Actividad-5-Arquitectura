
package servicio;

/** se importan las librería */
import java.util.List;
import modelo.Usuario;
import repositorio.UsuarioRepositorio;

public class UsuarioServicio {
    
/** se crea una instancia de la clase UsuarioRepositorio*/
    private UsuarioRepositorio usuarioRepositorio = new UsuarioRepositorio();
   
/** se traen los métodos de la clase UsuarioRepositorio*/
    public List<Usuario> registrarUsuarios(){
        return usuarioRepositorio.registrarUsuarios();
    }
    
    public void guardarUsuarios(Usuario usuario){
        usuarioRepositorio.guardarUsuarios(usuario);
    }
    
    public Usuario buscarUsuarios(Long identificacion){
        return usuarioRepositorio.buscarUsuarios(identificacion);
    }
    
    public void eliminarUsuario(Long identificacion){
        usuarioRepositorio.eliminarUsuario(identificacion);
    }

      
}
